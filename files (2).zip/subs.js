// netlify/functions/subs.js
//
// Backend for the "Find a Sub" feature.
// Storage: Netlify Blobs (built-in, zero-config key/value store).
// Email:   Resend (https://resend.com) — free tier is generous and the
//          Node SDK is a single fetch call, so no heavy dependency.
//
// Required environment variables (set in Netlify dashboard ->
// Site configuration -> Environment variables):
//   RESEND_API_KEY   - your Resend API key
//   SUB_FROM_EMAIL   - "2Bambirds@gmail.com" (must be a verified sender/domain in Resend)
//
// Deploy: this file just needs to live at netlify/functions/subs.js in
// your repo. Netlify picks it up automatically on the next deploy.
// It will be callable at:  /.netlify/functions/subs

const { getStore } = require("@netlify/blobs");

const FROM_EMAIL = process.env.SUB_FROM_EMAIL || "2Bambirds@gmail.com";
const RESEND_API_KEY = process.env.RESEND_API_KEY;

function subsStore() {
  // One Blobs "store" (namespace) called "subs". Each registered sub is
  // saved under the key "sub:<lowercased email>" so lookups are cheap
  // and emails are naturally deduped (re-registering just overwrites).
  return getStore("subs");
}

function normEmail(email) {
  return (email || "").trim().toLowerCase();
}

function json(statusCode, body) {
  return {
    statusCode,
    headers: {
      "Content-Type": "application/json",
      // Allow the browser fetch() from your site to call this function.
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST, OPTIONS"
    },
    body: JSON.stringify(body)
  };
}

async function sendEmail(to, subject, html) {
  if (!RESEND_API_KEY) {
    throw new Error("RESEND_API_KEY is not set");
  }
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from: FROM_EMAIL,
      to,
      subject,
      html
    })
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`Resend error ${res.status}: ${text}`);
  }
  return res.json();
}

// ---- action handlers ----

async function registerSub(store, data) {
  const email = normEmail(data.email);
  if (!email || !data.firstName || !data.lastName || !data.cell) {
    return json(400, { ok: false, error: "Missing required fields." });
  }
  const record = {
    firstName: String(data.firstName).trim(),
    lastName: String(data.lastName).trim(),
    cell: String(data.cell).trim(),
    email,
    permission: !!data.permission, // agreed to be contacted about sub opportunities
    wantsEvents: !!data.wantsEvents, // opted in to event/class announcements
    joinedAt: new Date().toISOString()
  };
  await store.setJSON(`sub:${email}`, record);
  return json(200, { ok: true });
}

async function checkSub(store, data) {
  const email = normEmail(data.email);
  if (!email) return json(400, { ok: false, error: "Missing email." });
  const record = await store.get(`sub:${email}`, { type: "json" });
  return json(200, { ok: true, isSub: !!record, permission: record ? !!record.permission : false });
}

async function requestSub(store, data) {
  const email = normEmail(data.email);
  if (!email || !data.name || !data.date || !data.time || !data.location || !data.numSubs) {
    return json(400, { ok: false, error: "Missing required fields." });
  }
  const requester = await store.get(`sub:${email}`, { type: "json" });
  if (!requester) {
    return json(403, {
      ok: false,
      error: "This email isn't in our sub database yet. Please become a sub first."
    });
  }

  // Log the request itself for record-keeping.
  const reqRecord = {
    name: String(data.name).trim(),
    email,
    date: String(data.date).trim(),
    time: String(data.time).trim(),
    location: String(data.location).trim(),
    numSubs: Number(data.numSubs) || 1,
    createdAt: new Date().toISOString()
  };
  const reqKey = `request:${Date.now()}-${email}`;
  await store.setJSON(reqKey, reqRecord);

  // Gather everyone who has given permission to be contacted (except the requester).
  const { blobs } = await store.list({ prefix: "sub:" });
  const recipients = [];
  for (const b of blobs) {
    const rec = await store.get(b.key, { type: "json" });
    if (rec && rec.permission && rec.email !== email) {
      recipients.push(rec.email);
    }
  }

  const subject = `Sub needed: ${reqRecord.date} at ${reqRecord.time}`;
  const html = `
    <p>Hi there,</p>
    <p><strong>${reqRecord.name}</strong> is looking for <strong>${reqRecord.numSubs}</strong>
       sub${reqRecord.numSubs === 1 ? "" : "s"} for a game:</p>
    <ul>
      <li><strong>Date:</strong> ${reqRecord.date}</li>
      <li><strong>Time:</strong> ${reqRecord.time}</li>
      <li><strong>Location:</strong> ${reqRecord.location}</li>
    </ul>
    <p>If you're interested and available, reply directly to
       <a href="mailto:${email}">${email}</a> to let ${reqRecord.name} know!</p>
    <p style="color:#888;font-size:12px">You're receiving this because you're on the
       2 Bam Birds sub list. — 2 Bam Birds</p>
  `;

  let sent = 0;
  const errors = [];
  for (const to of recipients) {
    try {
      await sendEmail(to, subject, html);
      sent++;
    } catch (err) {
      errors.push({ to, error: String(err.message || err) });
    }
  }

  return json(200, { ok: true, recipientsCount: recipients.length, sent, errors });
}

exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return json(200, {});
  }
  if (event.httpMethod !== "POST") {
    return json(405, { ok: false, error: "Method not allowed" });
  }

  let payload;
  try {
    payload = JSON.parse(event.body || "{}");
  } catch {
    return json(400, { ok: false, error: "Invalid JSON body" });
  }

  const { action, data } = payload;
  const store = subsStore();

  try {
    switch (action) {
      case "register":
        return await registerSub(store, data || {});
      case "check":
        return await checkSub(store, data || {});
      case "request":
        return await requestSub(store, data || {});
      default:
        return json(400, { ok: false, error: "Unknown action" });
    }
  } catch (err) {
    return json(500, { ok: false, error: String(err.message || err) });
  }
};
